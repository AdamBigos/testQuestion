import csv

file_name = open("./data/student_details.csv")

for x in file_name:
    # joe = x.replace(" , ", ",")
    # jokom = joe.replace(" ,", ",")
    # jo = jokom.replace(", ", ",")
    print(x)
    kom = x.split(",")
    print(kom)
