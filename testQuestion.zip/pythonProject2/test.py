d = {"a": 1, "b": 2, "c": 3}
d["a"] = 5
print(d)